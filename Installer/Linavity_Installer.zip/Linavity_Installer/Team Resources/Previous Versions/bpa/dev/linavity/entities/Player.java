package bpa.dev.linavity.entities;

public class Player {

	public Player(){
		
	}
	
}//end of class
