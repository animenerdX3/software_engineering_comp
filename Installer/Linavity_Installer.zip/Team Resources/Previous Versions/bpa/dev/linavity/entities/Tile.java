package bpa.dev.linavity.entities;

public class Tile {

}
