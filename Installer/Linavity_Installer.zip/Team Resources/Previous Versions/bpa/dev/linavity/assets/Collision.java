package bpa.dev.linavity.assets;

public class Collision {

}//class of class
